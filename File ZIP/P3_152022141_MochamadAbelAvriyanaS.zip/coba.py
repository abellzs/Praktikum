import sys
import cv2
import matplotlib.pyplot as plt
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
import numpy as np


class ShowImage(QMainWindow):
    def __init__(self):
        super(ShowImage, self).__init__()
        loadUi('showgui.ui', self)
        self.image = None
        self.loadButton.clicked.connect(self.loadClicked)
        self.grayButton.clicked.connect(self.grayClicked)
        self.actionCitra_Kecerahan.triggered.connect(self.brightness)
        self.actionCitra_Kontras.triggered.connect(self.contrast)
        self.actioncontrast_stretching.triggered.connect(self.contrastStretching)
        self.actionCitra_Negative.triggered.connect(self.negative)
        self.actionCitra_Biner.triggered.connect(self.biner)
        self.actionHistogram_Grayscale.triggered.connect(self.grayHistogram)
        self.actionHistogram_RGB.triggered.connect(self.HistogramRGB)
        self.actionHistogram_Equalization.triggered.connect(self.EqualHistogram)
        self.actionTranslasi.triggered.connect(self.Translasi)

        # rotasi
        self.action_45_Derajat.triggered.connect(self.rotasi_minus45)
        self.action90_Derajat.triggered.connect(self.rotasi90derajat)
        self.action45_Derajat.triggered.connect(self.rotasi45derajat)
        self.actionminus_90_Derajat.triggered.connect(self.rotasi_minus90)
        self.action180_Derajat.triggered.connect(self.rotasi180derajat)
        #transpose
        self.actionTranspose.triggered.connect(self.transpose)

        #zoom in
        self.action2x.triggered.connect(self.zoomIn2x)
        self.action3x.triggered.connect(self.zoomIn3x)
        self.action4x.triggered.connect(self.zoomIn4x)
        #zoom out
        self.action1_2.triggered.connect(self.zoomOut1_2)
        self.action1_4.triggered.connect(self.zoomOut1_4)
        self.action3_4.triggered.connect(self.zoomOut3_4)
        #crop
        self.actionCrop.triggered.connect(self.crop)
        #aritmatika
        self.actionTambah_dan_Kurang.triggered.connect(self.aritmatika)
        self.actionBoolean.triggered.connect(self.boolean)
    def loadClicked(self):
        self.image = cv2.imread('ktp.jpg')
        if self.image is not None:
            self.displayImage(1)

    def displayImage(self, windows=1):
        if self.image is None:
            return

        qformat = QImage.Format_Indexed8
        if len(self.image.shape) == 3:  # row[0],col[1],channel[2]
            if (self.image.shape[2]) == 4:
                qformat = QImage.Format_RGBA8888
            else:
                qformat = QImage.Format_RGB888

        img = QImage(self.image, self.image.shape[1], self.image.shape[0], self.image.strides[0], qformat)
        img = img.rgbSwapped()

        if windows == 1:
            self.imgLabel.setPixmap(QPixmap.fromImage(img))
            self.imgLabel.setAlignment(QtCore.Qt.AlignHCenter | QtCore.Qt.AlignVCenter)
            self.imgLabel.setScaledContents(True)

        if windows == 2:
            gray_pixmap = QPixmap.fromImage(img).toImage().convertToFormat(QImage.Format_Grayscale8)
            self.imgLabel2.setPixmap(QPixmap.fromImage(gray_pixmap))
            self.imgLabel2.setAlignment(QtCore.Qt.AlignHCenter | QtCore.Qt.AlignVCenter)
            self.imgLabel2.setScaledContents(True)

    def grayClicked(self):
        # if self.image is not None:
            H, W = self.image.shape[:2]
            gray = np.zeros((H, W), np.uint8)
            for i in range(H):
                for j in range(W):
                    gray[i, j] = np.clip(0.299 * self.image[i, j, 0] +
                                         0.587 * self.image[i, j, 1] +
                                         0.114 * self.image[i, j, 2], 0, 255)
            self.image = gray
            self.displayImage(2)

    def brightness(self):
        # error handling
        try :
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except :
            pass

        H, W = self.image.shape[:2]
        brightness = 80
        for i in range(H):
            for j in range(W):
                a = self.image.item(i,j)
                b = np.clip(a + brightness, 0, 255)

                self.image.itemset((i, j), b)
        self.displayImage(1)

    def contrast(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]
        contrast = 1.7
        for i in range(H):
            for j in range(W):
                a = self.image.item(i, j)
                b = np.clip(a * contrast, 0, 255)

                self.image.itemset((i, j), b)
        self.displayImage(1)

    def contrastStretching(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]
        minV = np.min(self.image)
        maxV = np.max(self.image)

        for i in range(H):
            for j in range(W):
                a = self.image.item(i, j)
                b = float(a - minV) / (maxV - minV) * 255

                self.image.itemset((i, j), b)

        self.displayImage(1)

    def negative(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]

        for i in range(H):
            for j in range(W):
                pixel_value = self.image.item(i, j)
                negative_value = 255 - pixel_value

                self.image.itemset((i, j), negative_value)

        self.displayImage(1)

    def biner(self):
        # Error handling
        try:
            # Convert the image to grayscale if it's not already
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        # Get the dimensions of the image
        H, W = self.image.shape[:2]

        # Iterate through each pixel of the image
        for i in range(H):
            for j in range(W):
                # Get the pixel value at (i, j)
                pixel_value = self.image.item(i, j)
                # If the pixel value is greater than or equal to the threshold, set it to 255 (white), otherwise set it to 0 (black)
                if pixel_value == 100:
                    self.image.itemset((i, j), 0)
                elif pixel_value < 180:
                    self.image.itemset((i, j), 1)
                elif pixel_value > 180:
                    self.image.itemset((i, j), 255)
                else:
                    self.image.itemset((i, j), 0)

        # Display the binary image
        self.displayImage(2)

    def grayHistogram(self):
        # if self.image is not None:
            H, W = self.image.shape[:2]
            gray = np.zeros((H, W), np.uint8)
            for i in range(H):
                for j in range(W):
                    gray[i, j] = np.clip(0.299 * self.image[i, j, 0] +
                                         0.587 * self.image[i, j, 1] +
                                         0.114 * self.image[i, j, 2], 0, 255)
            self.image = gray
            self.displayImage(2)
            plt.hist(self.image.ravel(), 255, [0, 255]) #membuat histogram nya dari pixel
            plt.show()

    def HistogramRGB(self):
        color = ('b', 'g', 'r') #warna blue green dan red
        for i, col in enumerate(color): #perulangan untuk setiap warna
            # fungsi untuk menghitung histogram dari setiap kumpulan array
            histo=cv2.calcHist([self.image],[i], None, [256], [0, 256])
            plt.plot(histo,color=col) #plotting histogram
            plt.xlim([0, 256]) #mengatur batas sumbu x
        plt.show()

    def EqualHistogram(self):
        # mengubah image array jadi 1 dimensu
        hist, bins = np.histogram(self.image.flatten(), 256, [0, 256])
        cdf = hist.cumsum() # menghitung jumlah kumualtif array
        cdf_normalized = cdf * hist.max() / cdf.max() # normalisasi
        cdf_m = np.ma.masked_equal(cdf, 0) # nge masking
        cdf_m = (cdf_m - cdf_m.min()) * 255 / (cdf_m.max() - cdf_m.min()) #perhitungannya
        cdf = np.ma.filled(cdf_m, 0).astype("uint8") #mengisi nilai array dengan skalar
        self.image = cdf[self.image] #mengganti nilai array menjadi nilai kumulatif
        self.displayImage(2)

        # membuat plotting
        plt.plot(cdf_normalized, color='b')
        plt.hist(self.image.flatten(), 256, [0, 256], color='r')
        plt.xlim([0, 256])
        plt.legend(('cdf', 'histogram'), loc='upper left')
        plt.show()

    def Translasi(self):
        h, w = self.image.shape[:2]
        quarter_h, quarter_w = h / 4, w / 4
        T = np.float32([[1, 0, quarter_w], [0, 1, quarter_h]]) #matriks
        img = cv2.warpAffine(self.image, T, (w, h))
        self.image = img
        self.displayImage(2)

    def transpose(self):
        self.image = cv2.transpose(self.image)
        self.displayImage(2)

    def rotasi(self, degree):
        h, w = self.image.shape[:2] #mengambil lebar dan tinggi dari gambar
        rotationMatrix = cv2.getRotationMatrix2D((w / 2, h / 2), degree, 1) #membuat rotasi matriks
        #mengambil nilai cosinus dari sudut rotasi dari matriks rotasi
        cos = np.abs(rotationMatrix[0, 0])
        sin = np.abs(rotationMatrix[0, 1])
        # menghitunf dimensi baru dari gambar yang telah dirotasi
        nW = int((h * sin) + (w * cos))
        nH = int((h * cos) + (w * sin))
        # memnyesuaikan matriks rotasi
        rotationMatrix[0, 2] += (nW / 2) - w / 2
        rotationMatrix[1, 2] += (nH / 2) - h / 2
        # memperbarui image dengan gambar yang sudha diputar
        rot_image = cv2.warpAffine(self.image, rotationMatrix, (nH, nW))
        self.image = rot_image
        self.displayImage(2)

    def rotasi_minus45(self):
        self.rotasi(-45)
    def rotasi45derajat(self):
        self.rotasi(45)
    def rotasi_minus90(self):
        self.rotasi(-90)
    def rotasi90derajat(self):
        self.rotasi(90)
    def rotasi180derajat(self):
        self.rotasi(180)


    def zoomIn(self, skala):
        resize_image = cv2.resize(self.image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original', self.image)
        cv2.imshow('Zoom In', resize_image)
        cv2.waitKey()

    def zoomIn2x(self):
        self.zoomIn(2)
    def zoomIn3x(self):
        self.zoomIn(3)
    def zoomIn4x(self):
        self.zoomIn(4)

    def zoomOut(self, skala):
        resize_image = cv2.resize(self.image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original', self.image)
        cv2.imshow('Zoom In', resize_image)
        cv2.waitKey()
    def zoomOut1_2(self):
        self.zoomOut(0.5)
    def zoomOut1_4(self):
        self.zoomOut(0.25)
    def zoomOut3_4(self):
        self.zoomOut(.75)

    def crop(self):
        # Tentukan koordinat atau posisi x (row) dan y (coloum) awal yang diawali dari ujung kiri atas
        x = 100
        y = 100
        # Tentukan koordinat atau posisi x (row) dan y (coloum) akhir berakhir di ujung kanan bawah
        width = 300
        height = 100
        cropped_image = self.image[y:y + height, x:x + width]
        cv2.imshow('Original', self.image)
        cv2.imshow('Cropped', cropped_image)
        cv2.waitKey()

    def aritmatika(self):
        image1 = cv2.imread('ip15.jpg', 0)
        image2 = cv2.imread('ip7.jpg', 0)
        image_tambah = image1 + image2
        image_kurang = image1 - image2
        image_kali = image1 * image2
        image_bagi = image1 / image2
        cv2.imshow('Image 1 Original', image1)
        cv2.imshow('Image 2 Original', image2)
        cv2.imshow('Image 2 Tambah', image_tambah)
        cv2.imshow('Image 2 Kurang', image_kurang)
        cv2.imshow('Image 2 Kali', image_kali)
        cv2.imshow('Image 2 Bagi', image_bagi)
        cv2.waitKey()

    def boolean(self):
        image1 = cv2.imread('ip15.jpg', 1)
        image2 = cv2.imread('ip7.jpg', 1)
        image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
        image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)
        operasiAnd = cv2.bitwise_and(image1, image2)
        operasiOr = cv2.bitwise_or(image1, image2)
        operasiXor = cv2.bitwise_xor(image1, image2)
        cv2.imshow("Image 1 Original", image1)
        cv2.imshow("Image 2 Original", image2)
        cv2.imshow("Operasi AND", operasiAnd)
        cv2.imshow("Operasi OR", operasiOr)
        cv2.imshow("Operasi XOR", operasiXor)
        cv2.waitKey()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = ShowImage()
    window.setWindowTitle('showgui')
    window.show()
    sys.exit(app.exec_())
