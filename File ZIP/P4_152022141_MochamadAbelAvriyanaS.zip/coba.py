import sys
import cv2
import matplotlib.pyplot as plt
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
import numpy as np


class ShowImage(QMainWindow):
    def __init__(self):
        super(ShowImage, self).__init__()
        loadUi('showgui.ui', self)
        self.image = None
        self.loadButton.clicked.connect(self.loadClicked)
        self.grayButton.clicked.connect(self.grayClicked)
        self.actionCitra_Kecerahan.triggered.connect(self.brightness)
        self.actionCitra_Kontras.triggered.connect(self.contrast)
        self.actioncontrast_stretching.triggered.connect(self.contrastStretching)
        self.actionCitra_Negative.triggered.connect(self.negative)
        self.actionCitra_Biner.triggered.connect(self.biner)
        self.actionHistogram_Grayscale.triggered.connect(self.grayHistogram)
        self.actionHistogram_RGB.triggered.connect(self.HistogramRGB)
        self.actionHistogram_Equalization.triggered.connect(self.EqualHistogram)
        self.actionTranslasi.triggered.connect(self.Translasi)

        # rotasi
        self.action_45_Derajat.triggered.connect(self.rotasi_minus45)
        self.action90_Derajat.triggered.connect(self.rotasi90derajat)
        self.action45_Derajat.triggered.connect(self.rotasi45derajat)
        self.actionminus_90_Derajat.triggered.connect(self.rotasi_minus90)
        self.action180_Derajat.triggered.connect(self.rotasi180derajat)
        #transpose
        self.actionTranspose.triggered.connect(self.transpose)

        #zoom in
        self.action2x.triggered.connect(self.zoomIn2x)
        self.action3x.triggered.connect(self.zoomIn3x)
        self.action4x.triggered.connect(self.zoomIn4x)
        #zoom out
        self.action1_2.triggered.connect(self.zoomOut1_2)
        self.action1_4.triggered.connect(self.zoomOut1_4)
        self.action3_4.triggered.connect(self.zoomOut3_4)
        #crop
        self.actionCrop.triggered.connect(self.crop)
        #aritmatika
        self.actionTambah_dan_Kurang.triggered.connect(self.aritmatika)
        self.actionBoolean.triggered.connect(self.boolean)

        # operasi spasial
        self.actionFiltering_1.triggered.connect(self.Filtering1)
        self.actionFiltering_2.triggered.connect(self.Filtering2)
        self.action2x2.triggered.connect(self.Mean2x2)
        self.action3x3.triggered.connect(self.Mean3x3)
        self.actionGaussian.triggered.connect(self.Gaussian)
        self.actionSharpening_1.triggered.connect(self.Sharpening1)
        self.actionSharpening_2.triggered.connect(self.Sharpening2)
        self.actionSharpening_3.triggered.connect(self.Sharpening3)
        self.actionSharpening_4.triggered.connect(self.Sharpening4)
        self.actionSharpening_5.triggered.connect(self.Sharpening5)
        self.actionSharpening_6.triggered.connect(self.Sharpening6)
        self.actionLaplace.triggered.connect(self.Laplace)
        self.actionMedian_Filtering.triggered.connect(self.Median)
        self.actionMax_Filtering.triggered.connect(self.Max)
        self.actionMin_Filtering.triggered.connect(self.Min)
    def loadClicked(self):
        self.image = cv2.imread('nosie.jpg')
        if self.image is not None:
            self.displayImage(1)

    def displayImage(self, windows=1):
        if self.image is None:
            return

        qformat = QImage.Format_Indexed8
        if len(self.image.shape) == 3:  # row[0],col[1],channel[2]
            if (self.image.shape[2]) == 4:
                qformat = QImage.Format_RGBA8888
            else:
                qformat = QImage.Format_RGB888

        img = QImage(self.image, self.image.shape[1], self.image.shape[0], self.image.strides[0], qformat)
        img = img.rgbSwapped()

        if windows == 1:
            self.imgLabel.setPixmap(QPixmap.fromImage(img))
            self.imgLabel.setAlignment(QtCore.Qt.AlignHCenter | QtCore.Qt.AlignVCenter)
            self.imgLabel.setScaledContents(True)

        if windows == 2:
            gray_pixmap = QPixmap.fromImage(img).toImage().convertToFormat(QImage.Format_Grayscale8)
            self.imgLabel2.setPixmap(QPixmap.fromImage(gray_pixmap))
            self.imgLabel2.setAlignment(QtCore.Qt.AlignHCenter | QtCore.Qt.AlignVCenter)
            self.imgLabel2.setScaledContents(True)

    def grayClicked(self):
        # if self.image is not None:
            H, W = self.image.shape[:2]
            gray = np.zeros((H, W), np.uint8)
            for i in range(H):
                for j in range(W):
                    gray[i, j] = np.clip(0.299 * self.image[i, j, 0] +
                                         0.587 * self.image[i, j, 1] +
                                         0.114 * self.image[i, j, 2], 0, 255)
            self.image = gray
            self.displayImage(2)

    def brightness(self):
        # error handling
        try :
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except :
            pass

        H, W = self.image.shape[:2]
        brightness = 80
        for i in range(H):
            for j in range(W):
                a = self.image.item(i,j)
                b = np.clip(a + brightness, 0, 255)

                self.image.itemset((i, j), b)
        self.displayImage(1)

    def contrast(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]
        contrast = 1.7
        for i in range(H):
            for j in range(W):
                a = self.image.item(i, j)
                b = np.clip(a * contrast, 0, 255)

                self.image.itemset((i, j), b)
        self.displayImage(1)

    def contrastStretching(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]
        minV = np.min(self.image)
        maxV = np.max(self.image)

        for i in range(H):
            for j in range(W):
                a = self.image.item(i, j)
                b = float(a - minV) / (maxV - minV) * 255

                self.image.itemset((i, j), b)

        self.displayImage(1)

    def negative(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]

        for i in range(H):
            for j in range(W):
                pixel_value = self.image.item(i, j)
                negative_value = 255 - pixel_value

                self.image.itemset((i, j), negative_value)

        self.displayImage(1)

    def biner(self):
        # Error handling
        try:
            # Convert the image to grayscale if it's not already
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        # Get the dimensions of the image
        H, W = self.image.shape[:2]

        # Iterate through each pixel of the image
        for i in range(H):
            for j in range(W):
                # Get the pixel value at (i, j)
                pixel_value = self.image.item(i, j)
                # If the pixel value is greater than or equal to the threshold, set it to 255 (white), otherwise set it to 0 (black)
                if pixel_value == 100:
                    self.image.itemset((i, j), 0)
                elif pixel_value < 180:
                    self.image.itemset((i, j), 1)
                elif pixel_value > 180:
                    self.image.itemset((i, j), 255)
                else:
                    self.image.itemset((i, j), 0)

        # Display the binary image
        self.displayImage(2)

    def grayHistogram(self):
        # if self.image is not None:
            H, W = self.image.shape[:2]
            gray = np.zeros((H, W), np.uint8)
            for i in range(H):
                for j in range(W):
                    gray[i, j] = np.clip(0.299 * self.image[i, j, 0] +
                                         0.587 * self.image[i, j, 1] +
                                         0.114 * self.image[i, j, 2], 0, 255)
            self.image = gray
            self.displayImage(2)
            plt.hist(self.image.ravel(), 255, [0, 255]) #membuat histogram nya dari pixel
            plt.show()

    def HistogramRGB(self):
        color = ('b', 'g', 'r') #warna blue green dan red
        for i, col in enumerate(color): #perulangan untuk setiap warna
            # fungsi untuk menghitung histogram dari setiap kumpulan array
            histo=cv2.calcHist([self.image],[i], None, [256], [0, 256])
            plt.plot(histo,color=col) #plotting histogram
            plt.xlim([0, 256]) #mengatur batas sumbu x
        plt.show()

    def EqualHistogram(self):
        # mengubah image array jadi 1 dimensu
        hist, bins = np.histogram(self.image.flatten(), 256, [0, 256])
        cdf = hist.cumsum() # menghitung jumlah kumualtif array
        cdf_normalized = cdf * hist.max() / cdf.max() # normalisasi
        cdf_m = np.ma.masked_equal(cdf, 0) # nge masking
        cdf_m = (cdf_m - cdf_m.min()) * 255 / (cdf_m.max() - cdf_m.min()) #perhitungannya
        cdf = np.ma.filled(cdf_m, 0).astype("uint8") #mengisi nilai array dengan skalar
        self.image = cdf[self.image] #mengganti nilai array menjadi nilai kumulatif
        self.displayImage(2)

        # membuat plotting
        plt.plot(cdf_normalized, color='b')
        plt.hist(self.image.flatten(), 256, [0, 256], color='r')
        plt.xlim([0, 256])
        plt.legend(('cdf', 'histogram'), loc='upper left')
        plt.show()

    def Translasi(self):
        h, w = self.image.shape[:2]
        quarter_h, quarter_w = h / 4, w / 4
        T = np.float32([[1, 0, quarter_w], [0, 1, quarter_h]]) #matriks
        img = cv2.warpAffine(self.image, T, (w, h))
        self.image = img
        self.displayImage(2)

    def transpose(self):
        self.image = cv2.transpose(self.image)
        self.displayImage(2)

    def rotasi(self, degree):
        h, w = self.image.shape[:2] #mengambil lebar dan tinggi dari gambar
        rotationMatrix = cv2.getRotationMatrix2D((w / 2, h / 2), degree, 1) #membuat rotasi matriks
        #mengambil nilai cosinus dari sudut rotasi dari matriks rotasi
        cos = np.abs(rotationMatrix[0, 0])
        sin = np.abs(rotationMatrix[0, 1])
        # menghitunf dimensi baru dari gambar yang telah dirotasi
        nW = int((h * sin) + (w * cos))
        nH = int((h * cos) + (w * sin))
        # memnyesuaikan matriks rotasi
        rotationMatrix[0, 2] += (nW / 2) - w / 2
        rotationMatrix[1, 2] += (nH / 2) - h / 2
        # memperbarui image dengan gambar yang sudha diputar
        rot_image = cv2.warpAffine(self.image, rotationMatrix, (nH, nW))
        self.image = rot_image
        self.displayImage(2)

    def rotasi_minus45(self):
        self.rotasi(-45)
    def rotasi45derajat(self):
        self.rotasi(45)
    def rotasi_minus90(self):
        self.rotasi(-90)
    def rotasi90derajat(self):
        self.rotasi(90)
    def rotasi180derajat(self):
        self.rotasi(180)


    def zoomIn(self, skala):
        resize_image = cv2.resize(self.image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original', self.image)
        cv2.imshow('Zoom In', resize_image)
        cv2.waitKey()

    def zoomIn2x(self):
        self.zoomIn(2)
    def zoomIn3x(self):
        self.zoomIn(3)
    def zoomIn4x(self):
        self.zoomIn(4)

    def zoomOut(self, skala):
        resize_image = cv2.resize(self.image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original', self.image)
        cv2.imshow('Zoom In', resize_image)
        cv2.waitKey()
    def zoomOut1_2(self):
        self.zoomOut(0.5)
    def zoomOut1_4(self):
        self.zoomOut(0.25)
    def zoomOut3_4(self):
        self.zoomOut(.75)

    def crop(self):
        # Tentukan koordinat atau posisi x (row) dan y (coloum) awal yang diawali dari ujung kiri atas
        x = 100
        y = 100
        # Tentukan koordinat atau posisi x (row) dan y (coloum) akhir berakhir di ujung kanan bawah
        width = 300
        height = 100
        cropped_image = self.image[y:y + height, x:x + width]
        cv2.imshow('Original', self.image)
        cv2.imshow('Cropped', cropped_image)
        cv2.waitKey()

    def aritmatika(self):
        image1 = cv2.imread('ip15.jpg', 0)
        image2 = cv2.imread('ip7.jpg', 0)
        image_tambah = image1 + image2
        image_kurang = image1 - image2
        image_kali = image1 * image2
        image_bagi = image1 / image2
        cv2.imshow('Image 1 Original', image1)
        cv2.imshow('Image 2 Original', image2)
        cv2.imshow('Image 2 Tambah', image_tambah)
        cv2.imshow('Image 2 Kurang', image_kurang)
        cv2.imshow('Image 2 Kali', image_kali)
        cv2.imshow('Image 2 Bagi', image_bagi)
        cv2.waitKey()

    def boolean(self):
        image1 = cv2.imread('ip15.jpg', 1)
        image2 = cv2.imread('ip7.jpg', 1)
        image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
        image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)
        operasiAnd = cv2.bitwise_and(image1, image2)
        operasiOr = cv2.bitwise_or(image1, image2)
        operasiXor = cv2.bitwise_xor(image1, image2)
        cv2.imshow("Image 1 Original", image1)
        cv2.imshow("Image 2 Original", image2)
        cv2.imshow("Operasi AND", operasiAnd)
        cv2.imshow("Operasi OR", operasiOr)
        cv2.imshow("Operasi XOR", operasiXor)
        cv2.waitKey()

    def Konvolusi(self, X, F):
        # membaca ukuran tinggi dan lebar citra
        X_height = X.shape[0]
        X_width = X.shape[1]
        # membaca ukuran tinggi dan lebar kernel
        F_height = F.shape[0]
        F_width = F.shape[1]
        # mencari titik tengah kernel
        H = (F_height) // 2
        W = (F_width) // 2

        out = np.zeros((X_height, X_width))

        # mengatur pergerakan kernel dengan for
        for i in np.arange(H + 1, X_height - H):
            for j in np.arange(W + 1, X_width - W):
                sum = 0
                for k in np.arange(-H, H + 1):
                    # mengambil piksel dari zona
                    for l in np.arange(-W, W + 1):
                        a = X[i + k, j + l]  # mengambil piksel yang ada pada dalam citra
                        w = F[H + k, W + l]  # mengambil bobot yang ada pada kernel
                        sum += (w * a)  # menampung nilai total perkalian w * a
                out[i, j] = sum  # menampung hasil
        return out

    def Filtering1(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)  # mengubah citra menjadi greyscale
        kernel = np.array(
            # array kernel
            [
                [1, 1, 1],
                [1, 1, 1],
                [1, 1, 1]
            ])

        # parameter dari fungsi konvolusi 2d
        img_out = self.Konvolusi(img, kernel)
        print('Nilai Pixel Filtering A \n', img_out)  # memunculkan nilai pixel
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')  # bicubic memperhalus tepi citra
        plt.xticks([]), plt.yticks([])
        plt.show()  # Menampilkan gambar

    def Filtering2(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        kernel = np.array(
            # array kernel
            [
                [6, 0, -6],
                [6, 1, -6],
                [6, 0, -6]
            ]
        )

        img_out = self.Konvolusi(img, kernel)
        # memunculkan nilai pixel pada terminal
        print('Nilai Pixel Filtering B\n', img_out)
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        # mengatur lokasi tick dan label sumbu x dan y
        plt.xticks([]), plt.yticks([])
        plt.show()  # Menampilkan gambar

    # filtering 1 menghasilkan gmabar yang buram karena kernel rata2 mencampur nilai piksel di sekitar setiap piksel
    # filtering 2 menghasilkan gambar lebih jelas
    def Mean2x2(self):
        # mengganti intensitas pixel dengan rata-rata pixel
        mean = (1.0 / 4) * np.array(
            [  # array kernel 2x2
                [0, 0, 0],
                [0, 1, 1],
                [0, 1, 1]
            ]
        )
        img = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        img_out = self.Konvolusi(img, mean)
        print('Nilai Pixel Mean Filter 2x2 \n', img_out)  # memunculkan nilai pixel
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.xticks([]), plt.yticks([])  # mengatur lokasi tick dan label sumbu x dan y
        plt.show()

    def Mean3x3(self):
        # kernel 1/9
        mean = (1.0 / 9) * np.array(
            [  # array kernel 3x3
                [1, 1, 1],
                [1, 1, 1],
                [1, 1, 1]
            ]
        )
        img = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        img_out = self.Konvolusi(img, mean)
        print('Nilai Pixel Mean Filter 3x3\n', img_out)  # memunculkan nilai pixel
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.xticks([]), plt.yticks([])  # mengatur lokasi tick, label sumbu x dan y
        plt.show() # menampilkan gambar

    # mean 2x2 efek blur lebih ringan tidak terlalu tajam
    # mean 3x3 efek blur lebih kuat dan detail si gambar lebih halus

    def Gaussian(self):
        gausian = (1.0 / 345) * np.array(
            # Kernel gaussian
            [
                [1, 5, 7, 5, 1],
                [5, 20, 33, 20, 5],
                [7, 33, 55, 33, 7],
                [5, 20, 33, 20, 5],
                [1, 5, 7, 5, 1]
            ]
        )
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        img_out = self.Konvolusi(img, gausian)
        print('Nilai Pixel Gaussian \n', img_out)  # memunculkan nilai pixel p
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.xticks([]), plt.yticks([])  # mengatur lokasi tick, label sumbu x dan y
        plt.show()
        # lebih ke penghilang noise, pengaburan citra dan penghalusan gambar

    def Sharpening1(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sharpe = np.array(
            [
                [-1, -1, -1],
                [-1, 8, -1],
                [-1, -1, -1]
            ]
        )
        img_out = self.Konvolusi(img, sharpe)
        cv2.imshow('Original', img)
        print('Nilai Pixel Kernel i \n', img_out)  # memunculkan nilai pixel pada terminal
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()

    def Sharpening2(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sharpe = np.array(
            [
                [-1, -1, -1],
                [-1, 9, -1],
                [-1, -1, -1]
            ])
        img_out = self.Konvolusi(img, sharpe)
        cv2.imshow('Original', img)
        print('Nilai Pixel Kernel ii \n', img_out)  # memunculkan nilai pixel pada terminal
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()

    def Sharpening3(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sharpe = np.array(
            [
                [0, -1, 0],
                [-1, 5, -1],
                [0, -1, 0]
            ]
        )
        img_out = self.Konvolusi(img, sharpe)
        print('Nilai Pixel Kernel iii \n', img_out)  # memunculkan nilai pixel pada terminal
        cv2.imshow('Original', img)
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()

    def Sharpening4(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sharpe = np.array(
            [
                [1, -2, 1],
                [-2, 5, -2],
                [1, 2, 1]
            ]
        )
        img_out = self.Konvolusi(img, sharpe)
        print('Nilai Pixel Kernel iv \n', img_out)  # memunculkan nilai pixel pada terminal
        cv2.imshow('Original', img)
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()

    def Sharpening5(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sharpe = np.array(
            [
                [1, -2, 1],
                [-2, 4, -2],
                [1, -2, 1]
            ]
        )
        img_out = self.Konvolusi(img, sharpe)
        print('Nilai Pixel Kernel v \n', img_out)  # memunculkan nilai pixel pada terminal
        cv2.imshow('Original', img)
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()

    def Sharpening6(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sharpe = np.array(
            [
                [0, 1, 0],
                [1, -4, 1],
                [0, 1, 0]
            ]
        )
        img_out = self.Konvolusi(img, sharpe)
        print('Nilai Pixel Kernel vi \n', img_out)  # memunculkan nilai pixel pada terminal
        cv2.imshow('Original', img)
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()

    # sharpening 1-5 sama sama untuk menajamkakn citra nya tergantung dari nilai kernel nya
    # sharpening 6 menajamkan bagian tepi
    def Laplace(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sharpe = (1.0 / 16) * np.array(  # nilai kernel
            [
                [0, 0, -1, 0, 0],
                [0, -1, -2, -1, 0],
                [-1, -2, 16, -2, -1],
                [0, -1, -2, -1, 0],
                [0, 0, -1, 0, 0]
            ])
        img_out = self.Konvolusi(img, sharpe)
        cv2.imshow('Original', img)
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()

    # menajamkan semua tepi dengan signifikan dibandingkan dengan fungsi sharpening
    # menandai bagian yang menjadi detail citra dan memperbaiki serta mengubah citra

    def Median(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)  # mengubah ke grayscale
        img_out = img.copy()
        H, W = img.shape[:2]  # tinggi dan lebar citra

        for i in np.arange(3, H - 3):
            for j in np.arange(3, W - 3):
                neighbors = []  # menampung nilai pixel
                for k in np.arange(-3, 4):
                    for l in np.arange(-3, 4):
                        # menampung hasil
                        a = img.item(i + k, j + l)
                        # menambahkan a ke neighbors
                        neighbors.append(a)
                neighbors.sort()
                median = neighbors[24]
                b = median
                img_out.itemset((i, j), b)
        print('Nilai Pixel Median Filter\n', img_out)  # memunculkan nilai pixel
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.xticks([]), plt.yticks([])
        plt.show()

    # mencari nilai tengah pixel setelah diurutkan
    # menghilangkan noise acak dan menghaluskan detail detail penting

    def Max(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        img_out = img.copy()
        H, W = img.shape[:2]

        # cek nilai setiap pixel
        for i in np.arange(3, H - 3):
            for j in np.arange(3, W - 3):
                max = 0
                # mencari nilai maximum
                for k in np.arange(-3, 4):
                    for l in np.arange(-3, 4):
                        # menampung nilai baca pixel
                        a = img.item(i + k, j + l)
                        if a > max:
                            max = a
                        b = max
                img_out.itemset((i, j), b)
        print('Nilai Pixel Maximun Filter \n', img_out)  # memunculkan nilai pixel
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.xticks([]), plt.yticks([])
        plt.show()

    def Min(self):
        img = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        img_out = img.copy()
        H, W = img.shape[:2]

        for i in np.arange(3, H - 3):  # mengecek nilai setiap pixel
            for j in np.arange(3, W - 3):
                min = 0
                for k in np.arange(-3, 4):  # mencari nilai maximun
                    for l in np.arange(-3, 4):
                        a = img.item(i + k, j + l)  # untuk menampung nilai baca pixel
                        if a < min:
                            min = a
                        b = min
                img_out.itemset((i, j), b)
        print('Nilai Pixel Minimun Filter \n', img_out)  # memunculkan nilai pixel
        plt.imshow(img_out, cmap='gray', interpolation='bicubic')
        plt.xticks([]), plt.yticks([])
        plt.show()

    # max mengganti nilai pixel dengan maksimum yang dipengaruhi piksel tetangga
    # min mengganti nilai pixel dengan minimum efek yang dipengaruhi piksel tetangga sih di foto ini jadi item

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = ShowImage()
    window.setWindowTitle('showgui')
    window.show()
    sys.exit(app.exec_())
