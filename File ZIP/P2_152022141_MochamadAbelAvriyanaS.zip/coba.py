import sys
import cv2
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
import numpy as np

class ShowImage(QMainWindow):
    def __init__(self):
        super(ShowImage, self).__init__()
        loadUi('showgui.ui', self)
        self.image = None
        self.loadButton.clicked.connect(self.loadClicked)
        self.grayButton.clicked.connect(self.grayClicked)
        self.actionCitra_Kecerahan.triggered.connect(self.brightness)
        self.actionCitra_Kontras.triggered.connect(self.contrast)
        self.actioncontrast_stretching.triggered.connect(self.contrastStretching)
        self.actionCitra_Negative.triggered.connect(self.negative)
        self.actionCitra_Biner.triggered.connect(self.biner)
    def loadClicked(self):
        self.image = cv2.imread('ktp.jpg')
        if self.image is not None:
            self.displayImage(1)

    def displayImage(self, windows=1):
        if self.image is None:
            return

        qformat = QImage.Format_Indexed8
        if len(self.image.shape) == 3:  # row[0],col[1],channel[2]
            if (self.image.shape[2]) == 4:
                qformat = QImage.Format_RGBA8888
            else:
                qformat = QImage.Format_RGB888

        img = QImage(self.image, self.image.shape[1], self.image.shape[0], self.image.strides[0], qformat)
        img = img.rgbSwapped()

        if windows == 1:
            self.imgLabel.setPixmap(QPixmap.fromImage(img))
            self.imgLabel.setAlignment(QtCore.Qt.AlignHCenter | QtCore.Qt.AlignVCenter)
            self.imgLabel.setScaledContents(True)

        if windows == 2:
            gray_pixmap = QPixmap.fromImage(img).toImage().convertToFormat(QImage.Format_Grayscale8)
            self.imgLabel2.setPixmap(QPixmap.fromImage(gray_pixmap))
            self.imgLabel2.setAlignment(QtCore.Qt.AlignHCenter | QtCore.Qt.AlignVCenter)
            self.imgLabel2.setScaledContents(True)

    def grayClicked(self):
        # if self.image is not None:
            H, W = self.image.shape[:2]
            gray = np.zeros((H, W), np.uint8)
            for i in range(H):
                for j in range(W):
                    gray[i, j] = np.clip(0.299 * self.image[i, j, 0] +
                                         0.587 * self.image[i, j, 1] +
                                         0.114 * self.image[i, j, 2], 0, 255)
            self.image = gray
            self.displayImage(2)

    def brightness(self):
        # error handling
        try :
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except :
            pass

        H, W = self.image.shape[:2]
        brightness = 80
        for i in range(H):
            for j in range(W):
                a = self.image.item(i,j)
                b = np.clip(a + brightness, 0, 255)

                self.image.itemset((i, j), b)
        self.displayImage(1)

    def contrast(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]
        contrast = 1.7
        for i in range(H):
            for j in range(W):
                a = self.image.item(i, j)
                b = np.clip(a * contrast, 0, 255)

                self.image.itemset((i, j), b)
        self.displayImage(1)

    def contrastStretching(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]
        minV = np.min(self.image)
        maxV = np.max(self.image)

        for i in range(H):
            for j in range(W):
                a = self.image.item(i, j)
                b = float(a - minV) / (maxV - minV) * 255

                self.image.itemset((i, j), b)

        self.displayImage(1)

    def negative(self):
        # error handling
        try:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.image.shape[:2]

        for i in range(H):
            for j in range(W):
                pixel_value = self.image.item(i, j)
                negative_value = 255 - pixel_value

                self.image.itemset((i, j), negative_value)

        self.displayImage(1)

    def biner(self):
        # Error handling
        try:
            # Convert the image to grayscale if it's not already
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        # Get the dimensions of the image
        H, W = self.image.shape[:2]

        # Iterate through each pixel of the image
        for i in range(H):
            for j in range(W):
                # Get the pixel value at (i, j)
                pixel_value = self.image.item(i, j)
                # If the pixel value is greater than or equal to the threshold, set it to 255 (white), otherwise set it to 0 (black)
                if pixel_value == 100:
                    self.image.itemset((i, j), 0)
                elif pixel_value < 180:
                    self.image.itemset((i, j), 1)
                elif pixel_value > 180:
                    self.image.itemset((i, j), 255)

                else:
                    self.image.itemset((i, j), 0)

        # Display the binary image
        self.displayImage(2)

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = ShowImage()
    window.setWindowTitle('showgui')
    window.show()
    sys.exit(app.exec_())
